module.exports = {
  capitalize(event, context) {
    return event.data.toUpperString()
  },
}
